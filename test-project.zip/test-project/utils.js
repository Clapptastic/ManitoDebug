export const greeting = "Hello";
